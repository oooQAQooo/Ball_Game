package com.example.ball;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    SensorManager sm;
    Sensor s;
    RelativeLayout layout;
    int width, height;
    int ball_width = 50 , ball_height = 50;
    float vx = 0, vy = 0;
    int pos_x = 100, pos_y = 100;

    int star_x, star_y;

    int spike_top, xx;
    int sp2, sp3, sp4, sp5, sp6;

    int score = 0;

    //TextView showText;
    int level = 1;
    String str_lv = "Level " + level;


    int left1, right1, top1, bottom1, a1;
    int left2, right2, top2, bottom2, a2;
    int left3, right3, top3, bottom3, a3;
    int left4, right4, top4, bottom4, a4;
    int left5, right5, top5, bottom5, a5;
    int left6, right6, top6, bottom6, a6;

    int spike_y2, spike_y3, spike_y4, spike_y5, spike_y6;

    int height2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setWindowFeature();

        layout = findViewById(R.id.layout);
        width = layout.getWidth();
        height = layout.getHeight();

        DisplayMetrics metrics = new
                DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        width = metrics.widthPixels +50;
        height = metrics.heightPixels +50;

        int n;
        n = (int)(Math.random()*5+2);

        star_x = width /7*n - width/14;
        star_y = (int)((Math.random()*7/8) *height);

        blocks();
        setSpikes();

        final DrawView view= new DrawView(this);
        view.setMinimumHeight(500);
        view.setMinimumWidth(300);
        //通知view組件重繪
        view.invalidate();
        layout.addView(view);

        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

    }

    void setWindowFeature() {
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onSensorChanged(SensorEvent event){

        vx = (event.values[1]) *(level);
        vy = event.values[0] *(level);
        if (vx > 50){
            vx = 50;
        }
        else if ( vx < -50){
            vx = -50;
        }
        pos_x += vx;
        pos_y += vy;



        if ((pos_x < -50) || (pos_x + ball_width > width +50) ) {
            vx = 0;
            vy = 0;
            gameOver();
        }

        else if( (pos_y < -50) || (pos_y + ball_height > height +50) ) {
            vx = 0;
            vy = 0;
            gameOver();
        }


        bump(left1, a1, right1, height2);
        bump(left2, top2, right2, bottom2);
        bump(left2, a2, right2, height2);
        bump(left3, top3, right3, bottom3);
        bump(left3, a3, right3, height2);
        bump(left4, top4, right4, bottom4);
        bump(left4, a4, right4, height2);
        bump(left5, top5, right5, bottom5);
        bump(left5, a5, right5, height2);
        bump(left6, top6, right6, bottom6);
        bump(left6, a6, right6, height2);

        destroy(left2-spike_top, sp2, spike_y2, spike_y2+50);
        destroy(left3-spike_top, sp3, spike_y3, spike_y3+50);
        destroy(left4-spike_top, sp4, spike_y4, spike_y4+50);
        destroy(left5-spike_top, sp5, spike_y5, spike_y5+50);
        destroy(left6-spike_top, sp6, spike_y6, spike_y6+50);

        if( pos_x >= star_x -50 && pos_x <= star_x +50
                && pos_y >= star_y -50 && pos_y <= star_y +50){
            score += 100;
            level += 1;
            str_lv = "Level " + level;
/*
            String lv = "Level" + String.valueOf(level);
            TextView showText = findViewById(R.id.textView);
            showText.setText(lv);
*/
            pos_x = 100;
            pos_y = 100;

            int n;
            n = (int)(Math.random()*5+2);

            star_x = width /7*n - width/14;
            star_y = (int)((Math.random()*7/8) *height);

            setSpikes();

            blocks();
        }
    }

    private void gameOver() {
        sm.unregisterListener(this);
        AlertDialog.Builder alertDialog =
                new AlertDialog.Builder(MainActivity.this);
        int result = level - 1;
        String res = "Complete " + result + " levels!";
        alertDialog.setTitle(res);
        alertDialog.setMessage("Try again?");
        alertDialog.setPositiveButton("Yes", (dialogInterface, i) -> recreate());
        alertDialog.setCancelable(false);
        alertDialog.show();
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy){}

    @Override
    protected void onResume(){
        super.onResume();
        sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onPause(){
        super.onPause();
        sm.unregisterListener(this);
    }

    public void restart(View view) {
        recreate();
    }

    public class DrawView extends View {

        public DrawView(Context context) {
            super(context);
            // TODO Auto-generated constructor stub
        }

        @Override
        protected void onDraw(Canvas canvas) {

            invalidate();

            super.onDraw(canvas);
            // 建立初始畫布

            @SuppressLint("DrawAllocation") Paint p = new Paint();  // 創建畫筆
            p.setAntiAlias(true);   // 設置畫筆的鋸齒效果。 true是去除。
            p.setStyle(Paint.Style.FILL);//設置填滿



            p.setColor(Color.parseColor("#BB88EE"));
            canvas.drawRect(left1, a1, right1, height2, p);
            canvas.drawRect(left2, top2, right2, bottom2, p);
            canvas.drawRect(left2, a2, right2, height2, p);
            canvas.drawRect(left3, top3, right3, bottom3, p);
            canvas.drawRect(left3, a3, right3, height2, p);
            canvas.drawRect(left4, top4, right4, bottom4, p);
            canvas.drawRect(left4, a4, right4, height2, p);
            canvas.drawRect(left5, top5, right5, bottom5, p);
            canvas.drawRect(left5, a5, right5, height2, p);
            canvas.drawRect(left6, top6, right6, bottom6, p);
            canvas.drawRect(left6, a6, right6, height2, p);

            spikes();
            p.setColor(Color.parseColor("#CA2A6B"));

            @SuppressLint("DrawAllocation") Path path = new Path();
            path.moveTo(sp2, spike_y2);// 此點為多邊形的起點
            path.lineTo(sp2-spike_top, spike_y2+25);
            path.lineTo(sp2, spike_y2+50);
            path.close(); // 使這些點構成封閉的多邊形
            canvas.drawPath(path, p);

            @SuppressLint("DrawAllocation") Path path3 = new Path();
            path3.moveTo(sp3, spike_y3);// 此點為多邊形的起點
            path3.lineTo(sp3-spike_top, spike_y3+25);
            path3.lineTo(sp3, spike_y3+50);
            path3.close(); // 使這些點構成封閉的多邊形
            canvas.drawPath(path3, p);

            @SuppressLint("DrawAllocation") Path path4 = new Path();
            path4.moveTo(sp4, spike_y4);// 此點為多邊形的起點
            path4.lineTo(sp4-spike_top, spike_y4+25);
            path4.lineTo(sp4, spike_y4+50);
            path4.close(); // 使這些點構成封閉的多邊形
            canvas.drawPath(path4, p);

            @SuppressLint("DrawAllocation") Path path5 = new Path();
            path5.moveTo(sp5, spike_y5);// 此點為多邊形的起點
            path5.lineTo(sp5-spike_top, spike_y5+25);
            path5.lineTo(sp5, spike_y5+50);
            path5.close(); // 使這些點構成封閉的多邊形
            canvas.drawPath(path5, p);

            @SuppressLint("DrawAllocation") Path path6 = new Path();
            path6.moveTo(sp6, spike_y6);// 此點為多邊形的起點
            path6.lineTo(sp6-spike_top, spike_y6+25);
            path6.lineTo(sp6, spike_y6+50);
            path6.close(); // 使這些點構成封閉的多邊形
            canvas.drawPath(path6, p);


            p.setColor(Color.GREEN);
            canvas.drawCircle(star_x,star_y,30,p);

            p.setColor(Color.WHITE);
            canvas.drawCircle(pos_x,pos_y,50,p);

            p.setTextSize(80);
            canvas.drawText(str_lv,20,80, p);


        }
    }

    void bump(int L, int T, int R, int B) {

        if (pos_y > T - ball_height  && pos_y < T + ball_height && pos_x + 0.25*ball_width <= R && pos_x + 0.25*ball_width >= L && vy > 0){
            pos_y = T - ball_height;
            vy = 0;
        }
        if( pos_y < B + ball_height && pos_y > B - ball_height && pos_x + 0.25*ball_width <= R && pos_x + 0.25*ball_width >= L && vy < 0) {
            pos_y = B + ball_height;
            vy = 0;
        }

        if (pos_x < R + ball_width && pos_x > L + ball_width && pos_y > T - ball_height && pos_y < B && vx < 0) {
            pos_x = R + ball_width;
            vx = 0;
        }
        else if (pos_x > L - ball_width && pos_x < R - ball_width && pos_y > T - ball_height && pos_y < B && vx > 0) {
            pos_x = L - ball_width;
            vx = 0;
        }
    }

    void blocks(){
        left1 = width / 7;
        right1 = left1 + 70;
        top1 = 0;
        bottom1 = (int) (Math.random() * height * 0.9);
        a1 = bottom1 + 250;

        left2 = width / 7*2;
        right2 = left2 + 70;
        top2 = 0;
        bottom2 = (int) (Math.random() * height * 0.9);
        a2 = bottom2 + 250;

        left3 = width / 7*3;
        right3 = left3 + 70;
        top3 = 0;
        bottom3 = (int) (Math.random() * height * 0.9);
        a3 = bottom3 + 250;

        left4 = width / 7*4;
        right4 = left4 + 70;
        top4 = 0;
        bottom4 = (int) (Math.random() * height * 0.9);
        a4 = bottom4 + 250;

        left5 = width / 7*5;
        right5 = left5 + 70;
        top5 = 0;
        bottom5 = (int) (Math.random() * height * 0.9);
        a5 = bottom5 + 250;

        left6 = width / 7*6;
        right6 = left6 + 70;
        top6 = 0;
        bottom6 = (int) (Math.random() * height * 0.9);
        a6 = bottom6 + 250;

        height2 = height + 250;

    }

    void setSpikes(){
        if (level<=3){
            sp2 = left2;
            spike_y2 = (int)((Math.random()*7/8) *height);
            sp3 = left2;
            spike_y3 = spike_y2;
            sp4 = left2;
            spike_y4 = spike_y2;
            sp5 = left5;
            spike_y5 = (int)((Math.random()*7/8) *height);
            sp6 = left5;
            spike_y6 = spike_y5;
        }
        else if (level<=5){
            sp2 = left2;
            spike_y2 = (int)((Math.random()*7/8) *height);
            sp3 = left2;
            spike_y3 = spike_y2;
            sp4 = left4;
            spike_y4 = (int)((Math.random()*7/8) *height);
            sp5 = left4;
            spike_y5 = spike_y4;
            sp6 = left6;
            spike_y6 = (int)((Math.random()*7/8) *height);
        }
        else if (level<=10){
            sp2 = left2;
            spike_y2 = (int)((Math.random()*7/8) *height);
            sp3 = left3;
            spike_y3 = (int)((Math.random()*7/8) *height);
            sp4 = left4;
            spike_y4 = (int)((Math.random()*7/8) *height);
            sp5 = left5;
            spike_y5 = (int)((Math.random()*7/8) *height);
            sp6 = left5;
            spike_y6 = spike_y5;
        }
        else {
            sp2 = left2;
            spike_y2 = (int)((Math.random()*7/8) *height);
            sp3 = left3;
            spike_y3 = (int)((Math.random()*7/8) *height);
            sp4 = left4;
            spike_y4 = (int)((Math.random()*7/8) *height);
            sp5 = left5;
            spike_y5 = (int)((Math.random()*7/8) *height);
            sp6 = left6;
            spike_y6 = (int)((Math.random()*7/8) *height);
        }
    }

    void spikes(){
        if (spike_top == 0){
            xx = 5;
            spike_top += xx;
        }
        else if(spike_top == 200){
            xx = -2;
            spike_top += xx;
        }
        else{
            spike_top += xx;
        }
    }

    void destroy(int x_1, int x_2, int y_1, int y_2) {
        if (pos_x > x_1 - ball_width -10 && pos_x + ball_width <= x_2 &&
                pos_y > y_1 && pos_y < y_2 ) {

            vx = 0;
            vy = 0;
            gameOver();
        }
    }

}